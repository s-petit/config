 1
down vote
	

The solution given by David Foerster in the 1st commet worked for me. I'm ussing an Asus n750 with the MT7630 chipset. I followed his recomendation so: I went to the proposed link: https://github.com/neurobin/MT7630E/tree/e7130a42f8198cbf503a5a307175073c078bf340

Then I downloaded and unpacked the zipped file I opened a terminal and cd to the unpacked folder. In the terminal I directly wrote the code that are in the install file:

make
make install
sudo modprobe mt7630e
sudo modprobe mt76xx

and in that moment the wifi started to work. Thaks to Neurobin for such a fantastic job and thanks to David Foerster for the advice.
